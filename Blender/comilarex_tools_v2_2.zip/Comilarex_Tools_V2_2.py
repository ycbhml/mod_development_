import bpy
import re
from bpy.props import PointerProperty, StringProperty, EnumProperty
from bpy.types import Object, Operator, Panel
from mathutils import Vector
import webbrowser

bl_info = {
    "name": "Comilarex Tools",
    "author": "Comilarex",
    "version": (2, 2),
    "blender": (3, 6, 2),
    "description": "Matches vertex groups based on weight paint centroids and surface area. Also can flip and pull weight from other objects.",
    "category": "Object",
}

class WeightPaintMatchingPanel(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Weight Paint Matching"
    bl_idname = "OBJECT_PT_weight_paint_matching"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Weight Match'

    @classmethod
    def poll(cls, context):
        # Check if the active object is a mesh and the mode is Weight Paint
        return (context.object is not None and
                context.object.type == 'MESH' and
                context.mode == 'PAINT_WEIGHT')


    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Donation Button at the top
        row = layout.row()
        row.scale_y = 2.0
        row.operator("wm.open_donation_link", text="Support Development", icon='FUND')
        layout.separator(factor=0.5)

        # Match Weight Paints Section
        match_box = layout.box()
        match_col = match_box.column(align=True)
        match_col.label(text="Match Weight Paints", icon='FULLSCREEN_EXIT')
        match_col.prop(scene, "weight_paint_matching_target")
        match_col.prop(scene, "weight_paint_matching_base")
        match_button_row = match_col.row()
        match_button_row.scale_y = 1.5
        match_button_row.operator(WeightPaintMatchingOperator.bl_idname, text="Match Vertex Groups")
        match_col.separator(factor=0.8)
        match_col.operator(RenameUnknownVertexGroupsOperator.bl_idname, text="Renumber 'Unknown'")
        match_col.operator(SortVertexGroupsOperator.bl_idname, text="Sort Vertex Groups")

        # Flip Weights Section
        flip_box = layout.box()
        flip_col = flip_box.column(align=True)
        flip_col.label(text="Flip Weights", icon='MOD_MIRROR')
        flip_col.separator(factor=0.5)
        flip_col.prop(scene, "flip_weights_target_group", text="Target")
        flip_button_row = flip_col.row()
        flip_button_row.scale_y = 1.5
        flip_button_row.operator(FlipWeightsOperator.bl_idname, text="Flip")

        # Weight Swap Section
        swap_box = layout.box()
        swap_col = swap_box.column(align=True)
        swap_col.label(text="Weight Swap", icon='DUPLICATE')
        swap_col.separator(factor=0.5)
        swap_col.prop(scene, "weight_swap_obj_a", text="Ref")
        swap_button_row = swap_col.row()
        swap_button_row.scale_y = 1.5
        swap_button_row.operator("object.weight_swap", text="Swap")

            
#   MATCH WEIGHT PAINTS

class OpenDonationLink(bpy.types.Operator):
    """Open the donation page in a web browser"""
    bl_idname = "wm.open_donation_link"
    bl_label = "Support Development"
    
    def execute(self, context):
        donation_url = "https://ko-fi.com/comilarex"
        webbrowser.open(donation_url)
        return {'FINISHED'}

class WeightPaintMatchingOperator(bpy.types.Operator):
    """Matches Vertex groups. 
    Will try to rename the vertex groups from the 'Target' to the 'Reference'"""
    bl_idname = "object.weight_paint_matching"
    bl_label = "Match Weight Paints"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        base_obj = context.scene.weight_paint_matching_base
        target_obj = context.scene.weight_paint_matching_target

        if base_obj and target_obj:
            match_vertex_groups(base_obj, target_obj)
            self.report({'INFO'}, "Vertex groups matched.")
        else:
            self.report({'ERROR'}, "One or more objects not found.")

        return {'FINISHED'}

def get_weighted_center(obj, vgroup):
    total_weight_area = 0.0
    weighted_position_sum = Vector((0.0, 0.0, 0.0))

    # Calculate the area influenced by each vertex
    vertex_influence_area = calculate_vertex_influence_area(obj)

    for vertex in obj.data.vertices:
        weight = get_vertex_group_weight(vgroup, vertex)
        influence_area = vertex_influence_area[vertex.index]
        weight_area = weight * influence_area

        if weight_area > 0:
            weighted_position_sum += obj.matrix_world @ vertex.co * weight_area
            total_weight_area += weight_area

    if total_weight_area > 0:
        return weighted_position_sum / total_weight_area
    else:
        return None

def calculate_vertex_influence_area(obj):
    vertex_area = [0.0] * len(obj.data.vertices)
    
    for face in obj.data.polygons:
        # Assuming the area is evenly distributed among the vertices
        area_per_vertex = face.area / len(face.vertices)
        for vert_idx in face.vertices:
            vertex_area[vert_idx] += area_per_vertex

    return vertex_area

def get_vertex_group_weight(vgroup, vertex):
    for group in vertex.groups:
        if group.group == vgroup.index:
            return group.weight
    return 0.0


def match_vertex_groups(base_obj, target_obj):
    # Rename all vertex groups in base_obj to "unknown"
    for base_group in base_obj.vertex_groups:
        base_group.name = "unknown"

    # Precompute centers for all target vertex groups
    target_centers = {}
    for target_group in target_obj.vertex_groups:
        target_centers[target_group.name] = get_weighted_center(target_obj, target_group)

    # Perform the matching and renaming process
    for base_group in base_obj.vertex_groups:
        base_center = get_weighted_center(base_obj, base_group)
        if base_center is None:
            continue

        best_match = None
        best_distance = float('inf')

        for target_group_name, target_center in target_centers.items():
            if target_center is None:
                continue

            distance = (base_center - target_center).length
            if distance < best_distance:
                best_distance = distance
                best_match = target_group_name

        if best_match:
            base_group.name = best_match
            
           
            
            
#   RENAME UNKNOWN
class RenameUnknownVertexGroupsOperator(bpy.types.Operator):
    """Renumber 'unknown' Vertex Groups"""
    bl_idname = "object.renumber_unknown_vertex_groups"
    bl_label = "Renumber 'Unknown' Groups"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is not None and obj.type == 'MESH':
            # Find all 'unknown' vertex groups
            unknown_groups = [group for group in obj.vertex_groups if group.name.startswith("unknown")]
            
            # Sort existing groups that are not 'unknown' by their names converted to numbers
            existing_numbers = sorted([int(g.name) for g in obj.vertex_groups if g.name.isdigit()], key=int)

            # Find missing numbers in the sequence
            missing_numbers = sorted(set(range(len(obj.vertex_groups))) - set(existing_numbers))

            # Rename 'unknown' groups to use missing numbers
            for i, group in enumerate(unknown_groups):
                if i < len(missing_numbers):
                    group.name = str(missing_numbers[i])
                else:
                    # If there are more 'unknown' groups than missing numbers, start appending from max number
                    group.name = str(max(existing_numbers) + i - len(missing_numbers) + 1)

            self.report({'INFO'}, "Renumbered 'unknown' vertex groups.")
        else:
            self.report({'ERROR'}, "No mesh object selected.")
        return {'FINISHED'}
            
            
            
            
#   SORT VERTEX GROUPS
class SortVertexGroupsOperator(bpy.types.Operator):
    """Sort Vertex Groups Numerically"""
    bl_idname = "object.sort_vertex_groups"
    bl_label = "Sort Vertex Groups"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is not None and obj.type == 'MESH':
            bpy.context.view_layer.objects.active = obj  # Ensure correct context
            sort_vertex_groups(obj)
            self.report({'INFO'}, "Vertex groups sorted numerically.")
        else:
            self.report({'ERROR'}, "No mesh object selected.")
        return {'FINISHED'}
             
def sort_vertex_groups(obj):
    sorted_group_names = sorted([g.name for g in obj.vertex_groups], key=numeric_key)
    
    for correct_idx, group_name in enumerate(sorted_group_names):
        set_active_vertex_group(obj, group_name)
        current_idx = obj.vertex_groups.find(group_name)

        while current_idx < correct_idx:
            bpy.ops.object.vertex_group_move(direction='DOWN')
            current_idx += 1
        while current_idx > correct_idx:
            bpy.ops.object.vertex_group_move(direction='UP')
            current_idx -= 1

def set_active_vertex_group(obj, group_name):
    group_index = obj.vertex_groups.find(group_name)
    if group_index != -1:
        obj.vertex_groups.active_index = group_index

def numeric_key(s):
    """
    Converts text to a list of integers and non-integers, for sorting purposes.
    Example: '10.001' -> [10, '.', 1]
    """
    return [int(text) if text.isdigit() else text for text in re.split('(\d+)', s)]

               










#   FLIP WEIGHTS
class FlipWeightsOperator(bpy.types.Operator):
    """Flip Weights Operator"""
    bl_idname = "object.flip_weights"
    bl_label = "Flip Weights"
    bl_options = {'REGISTER', 'UNDO'}

    target_group: bpy.props.StringProperty(name="Target Vertex Group")
    axis: bpy.props.EnumProperty(
        name="Axis",
        items=[
            ('X', "X", ""),
            ('Y', "Y", ""),
            ('Z', "Z", "")
        ],
        default='X'
    )

    def execute(self, context):
        original_obj = context.object

        # Validation check
        if not original_obj or original_obj.type != 'MESH':
            self.report({'ERROR'}, "No mesh object selected.")
            return {'CANCELLED'}
        if not original_obj.vertex_groups.active:
            self.report({'ERROR'}, "No active vertex group in the selected object.")
            return {'CANCELLED'}

        # Proceed with operation
        try:
            mirrored_obj = self.create_mirrored_object(original_obj, context)
            self.transfer_weights(original_obj, mirrored_obj, context)
            self.report({'INFO'}, "Weights transferred from Source to Target object.")
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        finally:
            # Cleanup
            if 'mirrored_obj' in locals():
                bpy.data.objects.remove(mirrored_obj, do_unlink=True)

        return {'FINISHED'}

    def create_mirrored_object(self, original_obj, context):
        # Duplicate and mirror the object
        mirrored_obj_data = original_obj.data.copy()
        mirrored_obj = bpy.data.objects.new(original_obj.name + "_mirrored", mirrored_obj_data)
        context.collection.objects.link(mirrored_obj)
        mirrored_obj.matrix_world = original_obj.matrix_world.copy()

        # Apply mirror transformation based on the selected axis
        axis_scale = {'X': (-1, 1, 1), 'Y': (1, -1, 1), 'Z': (1, 1, -1)}
        mirrored_obj.scale = axis_scale[self.axis]
        bpy.context.view_layer.objects.active = mirrored_obj
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        return mirrored_obj

    def transfer_weights(self, original_obj, mirrored_obj, context):
        # Ensure the correct vertex group is active
        target_group_name = context.scene.flip_weights_target_group
        target_group_index = original_obj.vertex_groups.find(target_group_name)
        if target_group_index == -1:
            raise ValueError(f"Target vertex group '{target_group_name}' not found.")

        original_obj.vertex_groups.active_index = target_group_index
        bpy.context.view_layer.objects.active = original_obj
        original_obj.select_set(True)
        mirrored_obj.select_set(True)

        # Transfer weights
        bpy.ops.object.data_transfer(use_reverse_transfer=True,
                                     data_type='VGROUP_WEIGHTS',
                                     layers_select_src='ACTIVE',
                                     layers_select_dst='ACTIVE',
                                     mix_mode='REPLACE',
                                     vert_mapping='POLYINTERP_NEAREST')

        # Deselect objects after transfer
        original_obj.select_set(False)
        mirrored_obj.select_set(False)
        bpy.ops.object.mode_set(mode='WEIGHT_PAINT')

    def set_active_vertex_group(self, obj, group_name):
        group_index = obj.vertex_groups.find(group_name)
        if group_index != -1:
            obj.vertex_groups.active_index = group_index












# SWAP WEIGHTS
class WeightSwapOperator(bpy.types.Operator):
    """This will take the weight from 'Source' and apply it to the currently active Object vertex group. 
    Select the vertex group in the active Object and press the button. 
    It will try to find the vertex group name in the 'Source' 
    and apply it to your selected Object vertex group"""
    bl_idname = "object.weight_swap"
    bl_label = "Swap Weights"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        source_obj = context.scene.weight_swap_obj_a
        target_obj = context.active_object  # Use the currently active object as the target

        if not source_obj or not target_obj:
            self.report({'WARNING'}, "Please ensure both Source and Target objects are selected.")
            return {'CANCELLED'}

        if target_obj.vertex_groups.active is None:
            self.report({'WARNING'}, "No active vertex group in Target Object. Please select one.")
            return {'CANCELLED'}

        target_vg_name = target_obj.vertex_groups.active.name
        source_vg = source_obj.vertex_groups.get(target_vg_name)

        if not source_vg:
            self.report({'ERROR'}, f"Vertex group '{target_vg_name}' not found in Source Object.")
            return {'CANCELLED'}

        source_obj.vertex_groups.active_index = source_vg.index
        bpy.context.view_layer.objects.active = target_obj
        target_obj.select_set(True)
        source_obj.select_set(True)

        bpy.ops.object.data_transfer(use_reverse_transfer=True,
                                     data_type='VGROUP_WEIGHTS',
                                     layers_select_src='ACTIVE',
                                     layers_select_dst='ACTIVE',
                                     mix_mode='REPLACE',
                                     vert_mapping='POLYINTERP_NEAREST')

        target_obj.select_set(False)
        source_obj.select_set(False)
        bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
        
        self.report({'INFO'}, "Weights transferred from Source to Target object.")
        return {'FINISHED'}
        
def register():
    """Register all classes and properties."""
    bpy.utils.register_class(OpenDonationLink)
    bpy.utils.register_class(WeightPaintMatchingOperator)
    bpy.utils.register_class(RenameUnknownVertexGroupsOperator)
    bpy.utils.register_class(SortVertexGroupsOperator)
    bpy.utils.register_class(FlipWeightsOperator)
    bpy.utils.register_class(WeightPaintMatchingPanel)
    bpy.types.Scene.weight_paint_matching_target = PointerProperty(
        name="Base",
        description="Object to copy weight paint data from",
        type=Object
    )
    bpy.types.Scene.weight_paint_matching_base = PointerProperty(
        name="Target",
        description="Object to receive weight paint data",
        type=Object
    )
    bpy.types.Scene.flip_weights_target_group = StringProperty(
        name="Target Vertex Group",
        description="The vertex group that receives the flipped weight paint"
    )
    bpy.types.Scene.flip_weights_axis = EnumProperty(
        name="Axis",
        items=[
            ('X', "X", ""),
            ('Y', "Y", ""),
            ('Z', "Z", "")
        ],
        default='X'
    )
    bpy.utils.register_class(WeightSwapOperator)
    bpy.types.Scene.weight_swap_obj_a = PointerProperty(
        name="Reference",
        description="Object from which to copy weight paint data",
        type=Object
    )

def unregister():
    """Unregister all classes and properties."""
    bpy.utils.unregister_class(OpenDonationLink)
    bpy.utils.unregister_class(WeightPaintMatchingOperator)
    bpy.utils.unregister_class(RenameUnknownVertexGroupsOperator)
    bpy.utils.unregister_class(SortVertexGroupsOperator)
    bpy.utils.unregister_class(FlipWeightsOperator)
    bpy.utils.unregister_class(WeightPaintMatchingPanel)
    del bpy.types.Scene.weight_paint_matching_target
    del bpy.types.Scene.weight_paint_matching_base
    del bpy.types.Scene.flip_weights_target_group
    del bpy.types.Scene.flip_weights_axis
    bpy.utils.unregister_class(WeightSwapOperator)
    del bpy.types.Scene.weight_swap_obj_a
    
if __name__ == "__main__":
    register()