


Mod Loading Error:

Mod is incompatible with current WWMI version!

Enable Compatibility Mode [Alt]+[F12]->[F10] to load it.

Press X to hide this message