Wuthering Waves Model Importer

Mod Installation:
1. Extract mod's archive
2. Put extracted folder into the Mods folder

Mod Hot Load (without game restart):
1. Install mod
2. Hide modded character from screen (switch to another)
3. Press F10 to reload WWMI

Mod User Hotkeys:
[F12]: Toggle this User Guide
[F6]: Toggle WWMI
[F10]: Reload WWMI and Save mods settings
[Alt]+[F12]: Toggle 0.6.X Compatibility Mode

Mod Developer Hotkeys:
[F9]: Disable WWMI while held
[Ctrl]+[F9]: Toggle Perfomance Monitor
[Ctrl]+[F12]: Toggle Hunting Mode Guide
Numpad [0]: Toggle Hunting Mode (green text)

You can find more mods at:
https://gamebanana.com/games/20357
https://discord.com/invite/agmg

Press F10 to not show this message again