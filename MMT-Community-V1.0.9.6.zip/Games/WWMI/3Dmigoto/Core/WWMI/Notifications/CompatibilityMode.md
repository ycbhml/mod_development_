Compatibility Mode

WWMI enabled Compatibility Mode to support 0.6.X mods

It costs around 5% FPS, but allows to use old mods until they are updated

You can use [Alt]+[F12] to toggle all outdated mods

Technical Details:
Global checks for vs-cb3 and vs-cb4 are deprecated, WWMI is using vb0 now

Press F10 to not show this message again