
# MMT-Community 
MigotoModTool Community Version

# Features
- Supports multiple games with a simple operating procedure.
- Fully graphical interface operation, convenient and easy to use.
- A detailed logging system for easy troubleshooting.
- Compatible with most other mod tools.
- Rapid iterative development.

This project is still under continuous development, testing, and improvement. I'm only using my spare time to develop for fun. If you have any questions, suggestions, or bug submissions, please contact me and provide feedback. Thank you.

# Usage
- Manually configure the target and launch paths in d3dx.ini for each game, and once configured, it can be used normally.
- MMT uses IndexBuffer to work. Keypad 0 opens the Hunting interface, while Keypads 7 and 8 search for IB. Keypad 9 copies the hash value of IB and fills it into MMT for use.
- MMT requires the installation of our matching Blender plugin to use, see Plugins\MMT.zip, MMT-Blender-Plugin only works on Blender3.6LTS.
- How to upgrade from old version MMT to new version MMT with just one click? Copy the content from the old version of Games and overwrite it with the new version of Games.

# Notice
- MMT's plugins contain closed source third-party tools. If you mind, please do not use them.
- Enabling track_texture_updates=1 may cause severe frame drops in some scenes, but it is set to enabled by default. If reverse feature extraction is not required, please manually disable it.
- The pre provided 3Dmigoto is the most suitable for MMT use, and using third-party 3Dmigoto may result in some functional failures.

# Technique Support
QQ Group 857993507

Discord: https://discord.gg/eCXdNyVnsM

# Third Party Used:
- easylogging++ (https://github.com/abumq/easyloggingpp)
- Boost 1.82 (https://www.boost.org/)
- Json for Morden C++ (https://github.com/nlohmann/json)
- Newtonsoft.Json.dll (https://www.newtonsoft.com/json)
- texconv.exe (https://github.com/microsoft/DirectXTex)

# LICENSE:
https://www.gnu.org/licenses/gpl-3.0.html

https://opensource.org/license/mit

https://www.boost.org/users/license.html

# Credit
MMT credit to original 3Dmigoto repository:
https://github.com/bo3b/3Dmigoto